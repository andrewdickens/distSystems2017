(function () {
    angular
        .module ("WebAppMaker", ["ngRoute", "textAngular"]);
})();

